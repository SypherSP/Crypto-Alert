module.exports = ({ env }) => ({
  auth: {
    secret: env('ADMIN_JWT_SECRET', '70abf8aaed2e1f05f0f14891b46b4a1d'),
  },
});
